import test from 'node:test';
import assert from 'node:assert/strict';
import { validateBook, validateEntry, validateSync, mulRound, toRow, fromRow, validDate } from '../lib/ledger.mjs';
const U = n => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const good = {
  jimpitan: { id: U(1), date: '2026-11-03', member: 'Ani', note: 'ronda', cents: 1000 },
  iuran: { id: U(2), date: '2026-11-03', member: 'Ani', month: '2026-11', cents: 2500000 },
  banksampah: { id: U(3), date: '2026-11-03', member: 'Ani', waste: 'Plastik', wCkg: 125, price: 333, cents: 416 },
  custom: { id: U(4), date: '2026-11-03', desc: 'Sewa tenda', dir: 'out', cents: 50000 },
};
test('entri valid diterima untuk setiap jenis', () => { for (const [k, e] of Object.entries(good)) assert.equal(validateEntry(k, e), null, k); });
test('mulRound: pembulatan setengah ke atas & batas aman', () => {
  assert.equal(mulRound(125, 333), 416); assert.equal(mulRound(1, 50), 1); assert.equal(mulRound(1, 49), 0);
  assert.equal(mulRound(150, 100), 150); assert.equal(mulRound(1e10, 1e10), null);
});
const bad = [
  ['jimpitan', { cents: 10.5 }], ['jimpitan', { cents: 0 }], ['jimpitan', { cents: -1 }], ['jimpitan', { cents: '100' }], ['jimpitan', { cents: 2 ** 53 }],
  ['jimpitan', { id: 'bukan-uuid' }], ['jimpitan', { date: '2026-02-30' }], ['jimpitan', { date: '1999-01-01' }], ['jimpitan', { note: 'x'.repeat(121) }],
  ['iuran', { month: '2026-13' }], ['iuran', { member: '' }], ['banksampah', { cents: 417 }], ['banksampah', { wCkg: 0 }], ['banksampah', { waste: '' }],
  ['banksampah', { price: 1.5 }], ['custom', { dir: 'x' }], ['custom', { desc: '   ' }], ['bukan-jenis', {}],
];
test('entri rusak ditolak', () => { for (const [k, patch] of bad) assert.notEqual(validateEntry(k, { ...(good[k] || good.custom), ...patch }), null, k + JSON.stringify(patch)); });
const book = { id: U(10), kind: 'iuran', name: 'Iuran RT 05', fee: 2500000, members: ['Ani', 'Budi'] };
test('buku: aturan dasar', () => {
  assert.equal(validateBook(book), null);
  for (const p of [{ id: 'x' }, { kind: 'zzz' }, { name: '' }, { name: 'x'.repeat(61) }, { fee: 0 }, { fee: 1.5 }, { members: ['Ani', 'ani'] }, { members: 'x' }, { members: Array(501).fill('a') }])
    assert.notEqual(validateBook({ ...book, ...p }), null, JSON.stringify(p).slice(0, 40));
});
test('validateSync: struktur, batas, duplikat', () => {
  assert.ok(!validateSync({ books: [book], entries: [{ ...good.iuran, bookId: book.id }], deletedBooks: [], deletedEntries: [U(99)] }).error);
  assert.ok(validateSync(null).error); assert.ok(validateSync({ books: 'x' }).error);
  assert.ok(validateSync({ entries: [{ ...good.iuran, bookId: 'bad' }] }).error);
  assert.ok(validateSync({ entries: [{ ...good.iuran, bookId: book.id }, { ...good.iuran, bookId: book.id }] }).error);
  assert.ok(validateSync({ deletedEntries: ['bukan-uuid'] }).error);
  assert.ok(validateSync({ entries: Array.from({ length: 2001 }, (_, i) => ({ ...good.custom, id: U(i + 1000), bookId: book.id })) }).error);
});
test('toRow/fromRow bolak-balik identik untuk semua jenis', () => {
  for (const [k, e] of Object.entries(good)) { const r = toRow(k, e); assert.deepEqual(fromRow(k, { id: e.id, date: e.date, ...r }), e, k); }
});
test('validDate', () => { assert.ok(validDate('2024-02-29')); assert.ok(!validDate('2026-02-29')); assert.ok(!validDate('2026-1-1')); });
