-- V18: Multi-Buku (Jimpitan, Iuran Bulanan, Bank Sampah, Kustom). Semua nilai uang = bilangan bulat sen.
CREATE TABLE ledger_books(
  id UUID PRIMARY KEY,
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('jimpitan','iuran','banksampah','custom')),
  name TEXT NOT NULL CHECK (char_length(name) BETWEEN 1 AND 60),
  fee_cents BIGINT NOT NULL DEFAULT 0 CHECK (fee_cents BETWEEN 0 AND 100000000000000),
  members JSONB NOT NULL DEFAULT '[]' CHECK (jsonb_typeof(members) = 'array'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ);
CREATE INDEX ledger_books_owner ON ledger_books(owner_user_id) WHERE deleted_at IS NULL;
CREATE TABLE ledger_entries(
  id UUID PRIMARY KEY,
  book_id UUID NOT NULL REFERENCES ledger_books(id) ON DELETE CASCADE,
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  entry_date DATE NOT NULL,
  member TEXT NOT NULL DEFAULT '' CHECK (char_length(member) <= 60),
  detail TEXT NOT NULL DEFAULT '' CHECK (char_length(detail) <= 120),
  month TEXT CHECK (month ~ '^\d{4}-(0[1-9]|1[0-2])$'),
  dir TEXT CHECK (dir IN ('in','out')),
  weight_ckg BIGINT CHECK (weight_ckg > 0),
  price_cents BIGINT CHECK (price_cents > 0),
  cents BIGINT NOT NULL CHECK (cents > 0 AND cents <= 100000000000000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ,
  -- pertahanan berlapis: total bank sampah harus = round(berat x harga / 100)
  CONSTRAINT bank_total CHECK (weight_ckg IS NULL OR price_cents IS NULL OR cents = floor((weight_ckg::numeric * price_cents + 50) / 100)::bigint));
CREATE UNIQUE INDEX ledger_iuran_unique ON ledger_entries(book_id, member, month) WHERE month IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX ledger_entries_book ON ledger_entries(book_id) WHERE deleted_at IS NULL;
CREATE INDEX ledger_entries_owner ON ledger_entries(owner_user_id) WHERE deleted_at IS NULL;
