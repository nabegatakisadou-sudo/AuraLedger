CREATE TABLE documents(
  id UUID PRIMARY KEY,
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  folder TEXT NOT NULL DEFAULT '',
  object_key TEXT UNIQUE NOT NULL,
  filename TEXT NOT NULL, mime_type TEXT NOT NULL,
  size_bytes BIGINT NOT NULL CHECK (size_bytes > 0),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','ready')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(), deleted_at TIMESTAMPTZ);
CREATE INDEX docs_owner ON documents(owner_user_id) WHERE deleted_at IS NULL;
