// Menyisipkan integrity (SRI sha384) ke tag <script src="https://cdn.jsdelivr.net/..."> pada public/index.html.
// Gagal-tertutup: bila unduhan gagal, proses berhenti dengan kode error (build Docker ikut gagal). Idempoten.
import fs from 'node:fs';
import crypto from 'node:crypto';
const file = new URL('../public/index.html', import.meta.url);
let html = fs.readFileSync(file, 'utf8');
const urls = [...new Set([...html.matchAll(/<script src="(https:\/\/cdn\.jsdelivr\.net\/[^"]+)"(?![^>]*integrity)[^>]*><\/script>/g)].map(m => m[1]))];
if (!urls.length) { console.log('SRI: tidak ada skrip CDN yang perlu diproses'); process.exit(0); }
for (const u of urls) {
  const src = process.env.SRI_OVERRIDE_BASE ? process.env.SRI_OVERRIDE_BASE + new URL(u).pathname : u; // override hanya untuk pengujian
  const r = await fetch(src);
  if (!r.ok) throw new Error(`SRI: gagal mengunduh ${u} (${r.status})`);
  const hash = 'sha384-' + crypto.createHash('sha384').update(Buffer.from(await r.arrayBuffer())).digest('base64');
  html = html.split(`<script src="${u}"`).join(`<script src="${u}" integrity="${hash}" crossorigin="anonymous"`);
  console.log('SRI', u, hash);
}
fs.writeFileSync(file, html);
