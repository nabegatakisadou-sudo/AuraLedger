CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE users(
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  google_sub TEXT UNIQUE NOT NULL,
  email TEXT NOT NULL, display_name TEXT,
  role TEXT NOT NULL DEFAULT 'owner' CHECK (role IN ('owner','admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE transactions(
  id UUID PRIMARY KEY,
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('income','expense')),
  description TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT '',
  amount NUMERIC(18,2) NOT NULL CHECK (amount >= 0),
  transaction_date DATE NOT NULL, note TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ);
CREATE INDEX tx_owner_date ON transactions(owner_user_id, transaction_date) WHERE deleted_at IS NULL;
CREATE TABLE shares(
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  scope_month TEXT NOT NULL CHECK (scope_month ~ '^\d{4}-(0[1-9]|1[0-2])$'),
  permission TEXT NOT NULL DEFAULT 'READ_ONLY' CHECK (permission = 'READ_ONLY'),
  token_hash TEXT UNIQUE NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL, revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE audit_logs(
  id BIGSERIAL PRIMARY KEY, actor_user_id UUID, action TEXT NOT NULL,
  resource_type TEXT, resource_id TEXT, ip_hash TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now());
