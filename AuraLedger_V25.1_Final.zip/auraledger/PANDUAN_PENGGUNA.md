# AuraLedger — panduan singkat pengguna

## Memasang
Buka alamat situs di Chrome (matikan "Situs desktop") -> menu ⋮ -> **Instal aplikasi**. Buka sekali saat online agar tersimpan untuk offline.

## Sehari-hari
- **Transaksi**: menu Transaksi -> Tambah. Kesalahan input (jumlah 0, tanggal fiktif, duplikat) ditolak/diperingatkan otomatis; ikon 🔔 menampilkan semua masalah data.
- **Dashboard**: pilih bulan (◀ ▶) dan periode Arus Kas (1–12 bulan, Per 6 bulan, Per semester, Semua bulan). Kartu saldo/pemasukan/pengeluaran mengikuti bulan terpilih.
- **Buku** (📒): Jimpitan, Iuran Bulanan (matriks Lunas/Belum), Bank Sampah (kg × harga), atau buku kustom. Ekspor/cetak per jenis buku dengan Audit Guard.
- **Dokumen**: folder & sub-folder, unggah PDF/gambar/TXT/CSV/DOCX/XLSX (tipe diperiksa dari isi file), dokumen tersimpan terenkripsi.
- **Laporan**: pilih template, **Ekspor XLSX** atau **Cetak**. Kolom "Status" di Excel menandai ✓ Sesuai / ✗ SELISIH.
- **Terhapus** (🗑): pulihkan transaksi, folder, buku, dokumen dalam 30 hari.

## Mencadangkan (PENTING — data ada di perangkat Anda)
1. Pengaturan -> Cadangan Google Drive: isi **frasa sandi** (min. 10 karakter; **catat**, tidak bisa dipulihkan jika lupa) -> Hubungkan -> Cadangkan.
2. Atau Dokumen -> Security Center -> Backup terenkripsi (berkas `.auraledger`).
3. Spanduk pengingat muncul di Dashboard bila 7 hari tanpa cadangan.

## Akun
Pengaturan -> Akun & ruang kerja -> Masuk dengan Google. Tiap akun punya ruang kerja sendiri. Keluar membersihkan tampilan; di perangkat bersama pilih "hapus salinan lokal". Di perangkat baru: Masuk -> isi frasa sandi -> Pulihkan cadangan terbaru.

## Bila ada masalah
Pengaturan -> **Pemeriksaan kesehatan aplikasi** -> Jalankan -> Salin laporan, lalu kirim ke pengembang (laporan tidak memuat email atau isi data).
