# AuraLedger V25 — status akhir & uji di perangkat Anda

## Sudah diuji otomatis (peramban nyata + server/Google/Drive tiruan)
Transaksi & Audit Guard · Buku (integer sen) & ekspor/cetak per jenis · Document Vault (sub-folder, validasi isi file, enkripsi AES-256-GCM) · Riwayat terhapus ·
Arus kas 1–12/Per 6 bulan/Per semester/Semua bulan · Arsip 12.000 transaksi · Cadangan terenkripsi & Google Drive · Akun & isolasi data per pengguna ·
CSP/SRI/XSS · PWA offline · tata letak 360–1366 px. Total >260 pemeriksaan + 7 uji unit.

## BELUM bisa dibuktikan oleh pengembang — mohon uji sendiri (±10 menit)
1. **Excel asli**: Laporan -> Ekspor XLSX -> buka di Excel/Google Sheets: tabel rapi, kolom Status "✓ Sesuai".
2. **Cetak**: Laporan -> Cetak -> pratinjau/PDF tampil rapi, warna template ikut.
3. **Google sungguhan**: Masuk dengan Gmail A -> tambah transaksi -> Cadangkan -> Keluar -> Masuk Gmail B (data A tidak tampil) -> Keluar -> Masuk A lagi (data kembali) -> hapus salinan lokal -> Pulihkan dari Drive.
4. **Pemeriksaan kesehatan aplikasi**: semua ✅ (⚠️ "penyimpanan permanen" wajar sampai aplikasi dipasang).
5. **APK** (opsional): workflow build.yml belum pernah dijalankan sampai selesai di GitHub; PWA dari Chrome lebih disarankan.

## Batas yang disengaja (jujur)
- Tidak ada perangkat lunak yang "100% bebas bug" atau "kebal peretasan"; pengujian penetrasi pihak ketiga dianjurkan sebelum memakai data sensitif (lihat PENTEST.md).
- Obfuscation/anti-debug tidak dipasang (hanya memperlambat penyalin; risiko merusak aplikasi).
- Cadangan Drive = salinan terenkripsi (bukan sinkron real-time); dua perangkat yang mengedit bersamaan -> cadangan terakhir menang.
- Pemulihan butuh frasa sandi cadangan. Kehilangan frasa = data cadangan tidak dapat dibuka.
- Salinan lokal akun yang disimpan masih bisa dibaca orang yang menguasai perangkat (dokumen terenkripsi; transaksi tidak).
- Hak cipta: kode & ikon orisinal; pihak ketiga: SheetJS (xlsx-js-style), Google Identity Services — periksa lisensi untuk kepastian hukum.
- iOS: lewat Safari "Tambahkan ke Layar Utama"; desktop: pasang PWA dari Chrome/Edge (pembungkus Tauri ditunda).
