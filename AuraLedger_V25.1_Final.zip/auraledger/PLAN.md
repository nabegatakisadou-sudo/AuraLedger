# AuraLedger — rencana teknis, keamanan, dan platform

## Arsitektur (satu basis kode)
PWA (HTML/JS) + backend Node/PostgreSQL + penyimpanan objek privat. Android: TWA via `build.yml`. Desktop: bungkus PWA dengan Tauri
(Windows/macOS/Linux, kecil & aman) atau pasang langsung dari Chrome/Edge. iOS: "Tambahkan ke Layar Utama" (Safari); app store butuh Mac + Apple Developer.
Flutter/React Native tidak dipilih: menulis ulang seluruh aplikasi tanpa keuntungan nyata untuk kasus ini.

## Keamanan (urutan prioritas)
1. Kepercayaan ada di server, bukan di aplikasi: login Google OIDC divalidasi server, data per-akun, URL bertanda tangan, token berbagi di-hash, rate limit, audit log.
2. Data di perangkat: cadangan AES-256-GCM (PBKDF2). Document Vault terenkripsi AES-256-GCM dengan kunci perangkat non-extractable (V16). Opsi lanjutan: kunci dari frasa sandi pengguna.
3. Lapisan aplikasi: CSP ketat, tanpa pustaka tak dikenal, pin versi + SRI untuk skrip CDN, dependensi diaudit (`npm audit`).
4. Obfuscation/anti-debug hanya memperlambat penyalin, tidak menghentikan; boleh ditambahkan saat build rilis (javascript-obfuscator) tetapi bukan pengganti no. 1–3.

## Hak cipta
Kode & ikon dibuat orisinal untuk proyek ini. Pihak ketiga: xlsx-js-style (lisensi open-source SheetJS), Google Identity Services (syarat Google).
Simpan daftar lisensi di repo; untuk kepastian hukum konsultasikan ke penasihat hukum.

## Peta jalan
V16 (selesai) Document Vault · V17 sinkron Multi-Buku ke cloud
· V18 SRI/CSP hardening + pengujian penetrasi · V19 pembungkus desktop Tauri.


## Status: FINISH (V25)
Semua modul pada rencana selesai dan teruji otomatis. Sisa: uji perangkat sendiri (CHECKLIST_FINAL.md), pengujian penetrasi pihak ketiga, dan opsional APK/Tauri.
