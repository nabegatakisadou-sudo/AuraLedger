# Cadangan Google Drive tanpa server (GitHub Pages)
1. console.cloud.google.com -> buat proyek -> APIs & Services -> Library -> aktifkan **Google Drive API**.
2. OAuth consent screen: User type **External**, isi nama aplikasi & email Anda; Scopes: tambahkan `.../auth/drive.appdata`; Test users: tambahkan email Gmail Anda; biarkan mode Testing.
3. Credentials -> Create credentials -> **OAuth client ID** -> Web application -> Authorized JavaScript origins: `https://AKUN.github.io` (tanpa path, tanpa garis miring di akhir). Salin Client ID.
4. Di aplikasi: Pengaturan -> kolom **Google OAuth Web Client ID** -> Simpan konfigurasi (kolom Backend URL dikosongkan).
5. Isi frasa sandi di kartu Backup terenkripsi (min. 10 karakter), lalu kartu Cadangan Google Drive -> Hubungkan -> Cadangkan.
Layar peringatan "Google belum memverifikasi aplikasi" normal untuk mode Testing: pilih Lanjutkan. Catat frasa sandi: tanpa itu cadangan tidak bisa dibuka.
