# Cadangan Google Drive tanpa server (GitHub Pages)
1. console.cloud.google.com -> buat proyek -> APIs & Services -> Library -> aktifkan **Google Drive API**.
2. OAuth consent screen: User type **External**, isi nama aplikasi & email Anda; Scopes: tambahkan `.../auth/drive.appdata`; Test users: tambahkan email Gmail Anda; biarkan mode Testing.
3. Credentials -> Create credentials -> **OAuth client ID** -> Web application -> Authorized JavaScript origins: `https://AKUN.github.io` (tanpa path, tanpa garis miring di akhir). Salin Client ID.
4. Di aplikasi: Pengaturan -> kolom **Google OAuth Web Client ID** -> Simpan konfigurasi (kolom Backend URL dikosongkan).
5. Di kartu Cadangan Google Drive: isi Frasa sandi (min. 10 karakter) di dua kolom, lalu Hubungkan -> Cadangkan.
Layar peringatan "Google belum memverifikasi aplikasi" normal untuk mode Testing: pilih Lanjutkan. Catat frasa sandi: tanpa itu cadangan tidak bisa dibuka.

## Login akun & ruang kerja per akun (V24)
- Tombol **Masuk dengan Google** (Pengaturan -> Akun & ruang kerja) meminta izin Drive + identitas dasar (`openid email profile`; cakupan dasar, tidak perlu verifikasi).
- Setiap akun punya ruang kerja lokal sendiri (transaksi, buku, folder, dokumen, riwayat terhapus). Mode tamu = data lama sebelum login.
- Login pertama dengan data tamu: aplikasi menawarkan memindahkannya ke akun (mode tamu lalu dikosongkan).
- **Keluar**: tampilan & memori dibersihkan; data di Google Drive tidak dihapus. Anda ditanya apakah salinan lokal akun juga dihapus (disarankan di perangkat bersama).
- Pulihkan di perangkat baru: Masuk -> isi frasa sandi cadangan -> **Pulihkan cadangan terbaru dari Drive**.
