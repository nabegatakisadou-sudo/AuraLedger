# Aurale Ledger V14 (final) — satu layanan: API + aplikasi (PWA)
Lokal:
1. `docker compose up -d` (PostgreSQL + MinIO); buat bucket **aurale-ledger-docs** di http://localhost:9001 (namaminio / nama_minio_dev_pw)
2. `cp .env.example .env` → isi GOOGLE_CLIENT_ID, JWT_SECRET (`openssl rand -hex 32`), ALLOWED_EMAILS. Set PUBLIC_BASE_URL=http://localhost:8080
3. `npm install && npm start` → buka http://localhost:8080 (konfigurasi backend terisi otomatis)
Google Cloud Console → OAuth Client (Web) → Authorized JavaScript origins: http://localhost:8080 (dan domain produksi Anda).

Produksi: deploy `Dockerfile` (mis. Fly.io / Railway / VPS) di belakang HTTPS, `docker run --env-file .env`. Database: PostgreSQL terkelola
(jalankan schema.sql lalu schema_v9.sql). Bucket R2/S3 privat + CORS: `[{"AllowedOrigins":["https://domain-anda"],"AllowedMethods":["PUT","GET"],"AllowedHeaders":["Content-Type","Content-Length"],"MaxAgeSeconds":3000}]`.
Pasang di Android: buka https://domain-anda di Chrome → "Pasang ke layar utama" (atau tombol di Pengaturan).
