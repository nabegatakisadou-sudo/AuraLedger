# AuraLedger V15 — satu layanan: API + aplikasi (PWA)
Lokal:
1. `docker compose up -d` (PostgreSQL + MinIO); buat bucket **aurale-ledger-docs** di http://localhost:9001 (namaminio / nama_minio_dev_pw)
2. `cp .env.example .env` → isi GOOGLE_CLIENT_ID, JWT_SECRET (`openssl rand -hex 32`), ALLOWED_EMAILS. Set PUBLIC_BASE_URL=http://localhost:8080
3. `npm install && npm start` → buka http://localhost:8080 (konfigurasi backend terisi otomatis)
Google Cloud Console → OAuth Client (Web) → Authorized JavaScript origins: http://localhost:8080 (dan domain produksi Anda).

Produksi: deploy `Dockerfile` (mis. Fly.io / Railway / VPS) di belakang HTTPS, `docker run --env-file .env`. Database: PostgreSQL terkelola
(jalankan schema.sql lalu schema_v9.sql). Bucket R2/S3 privat + CORS: `[{"AllowedOrigins":["https://domain-anda"],"AllowedMethods":["PUT","GET"],"AllowedHeaders":["Content-Type","Content-Length"],"MaxAgeSeconds":3000}]`.
Pasang di Android: buka https://domain-anda di Chrome → "Pasang ke layar utama" (atau tombol di Pengaturan).

## Build APK Android (opsional) — `.github/workflows/build.yml`
Syarat: server sudah ter-deploy di HTTPS. Di repo GitHub → Settings → Secrets and variables → Actions:
- Variable `APP_HOST` = domain Anda (mis. `ledger.domainanda.com`)
- Secret `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD` — buat sekali di komputer Anda:
  `keytool -genkeypair -v -keystore auraledger.keystore -alias auraledger -keyalg RSA -keysize 2048 -validity 10000`
  lalu `base64 -w0 auraledger.keystore` (simpan keystore & sandi dengan aman; kehilangannya = tidak bisa update aplikasi).
Jalankan: tab Actions → "Build AuraLedger" → Run workflow. Hasil: APK/AAB di Artifacts. Salin sidik jari dari Job Summary
ke `public/.well-known/assetlinks.json`, deploy ulang, agar aplikasi tampil layar penuh tanpa bilah alamat.

## Keamanan web (V17)
- CSP berbasis hash: skrip sisipan hasil injeksi dan atribut `onerror`/`onclick` diblokir peramban. Hash dihitung otomatis dari `public/index.html` saat server start — **restart server setiap kali index.html berubah**.
- SRI: `Dockerfile` menjalankan `node scripts/sri.mjs` (butuh internet saat build; build gagal bila unduhan gagal).
- CI: job `keamanan` menjalankan `npm audit` dan larangan atribut event inline/eval.

## Multi-Buku di cloud (V18)
Upgrade dari V9–V17: `psql "$DATABASE_URL" -f schema_v18.sql`. Endpoint: `GET /v1/books`, `POST /v1/books/sync`.
Aturan validasi di `lib/ledger.mjs` (diuji: `node --test tests/ledger.test.mjs`) dan diulang sebagai CHECK/UNIQUE di basis data.

## Pulihkan buku terhapus (V19)
Tidak ada skema baru. Endpoint: `POST /v1/books/:id/restore`, `DELETE /v1/trash/books/:id`; daftar sampah di `GET /v1/trash` (kini memuat `books`).

## Cadangan Google Drive (V20)
Di Google Cloud Console (proyek yang sama dengan OAuth Client): aktifkan **Google Drive API**, lalu pada layar persetujuan OAuth tambahkan cakupan
`https://www.googleapis.com/auth/drive.appdata` (folder aplikasi tersembunyi; bukan cakupan sensitif). Di aplikasi: Pengaturan -> isi frasa sandi di kartu
"Backup terenkripsi" -> kartu "Cadangan Google Drive". Berkas dienkripsi AES-256-GCM di perangkat sebelum diunggah; 10 cadangan terakhir disimpan.
Cadangan otomatis hanya berjalan selama aplikasi terbuka, izin Drive masih berlaku (token tidak disimpan di disk), dan frasa sandi terisi.
