import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import pg from 'pg';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { OAuth2Client } from 'google-auth-library';
import { S3Client, PutObjectCommand, GetObjectCommand, HeadObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { validateSync, validateEntry, toRow, fromRow } from './lib/ledger.mjs';

const { PORT = 8080, DATABASE_URL, GOOGLE_CLIENT_ID, JWT_SECRET, PUBLIC_BASE_URL, CORS_ORIGINS = '', ALLOWED_EMAILS = '' } = process.env;
if (!DATABASE_URL || !GOOGLE_CLIENT_ID || !PUBLIC_BASE_URL || !JWT_SECRET || JWT_SECRET.length < 32)
  throw new Error('Wajib: DATABASE_URL, GOOGLE_CLIENT_ID, PUBLIC_BASE_URL, JWT_SECRET (>=32 karakter)');

const pool = new pg.Pool({ connectionString: DATABASE_URL });
const google = new OAuth2Client(GOOGLE_CLIENT_ID);
const list = s => s.split(',').map(x => x.trim()).filter(Boolean);
const allowedEmails = list(ALLOWED_EMAILS).map(e => e.toLowerCase());
const origins = list(CORS_ORIGINS);
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const rp = n => 'Rp ' + Number(n).toLocaleString('id-ID');
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const limit = n => rateLimit({ windowMs: 60_000, limit: n, standardHeaders: true, legacyHeaders: false });
const wrap = fn => (req, res) => fn(req, res).catch(e => { console.error(e); res.status(500).json({ error: 'server_error' }); });
const audit = (uid, action, type, id, req) =>
  pool.query('INSERT INTO audit_logs(actor_user_id,action,resource_type,resource_id,ip_hash) VALUES($1,$2,$3,$4,$5)',
    [uid, action, type, id, sha(req.ip || '')]).catch(() => {});

// ===== V9: dokumen cloud (S3 / Cloudflare R2 / MinIO). Bucket privat; isi file tidak pernah lewat server. =====
const { S3_BUCKET, S3_ENDPOINT, S3_REGION = 'auto', S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY, MAX_FILE_MB = 25, USER_QUOTA_MB = 200 } = process.env;
const s3on = !!(S3_BUCKET && S3_ACCESS_KEY_ID && S3_SECRET_ACCESS_KEY);
const s3 = s3on ? new S3Client({ region: S3_REGION, endpoint: S3_ENDPOINT || undefined, forcePathStyle: !!S3_ENDPOINT,
  credentials: { accessKeyId: S3_ACCESS_KEY_ID, secretAccessKey: S3_SECRET_ACCESS_KEY } }) : null;
const MIMES = new Set(['application/pdf', 'image/png', 'image/jpeg', 'image/webp', 'text/plain', 'text/csv',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']);
const maxFile = MAX_FILE_MB * 1048576, quota = USER_QUOTA_MB * 1048576;
const needS3 = (_q, res, next) => s3on ? next() : res.status(503).json({ error: 'storage_not_configured' });
const DOC_COLS = 'id, filename, mime_type AS mime, size_bytes::float8 AS size, folder, created_at';

const TRASH_DAYS = Math.max(1, parseInt(process.env.TRASH_DAYS, 10) || 30);
const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false, crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' } })); // popup Google Sign-In butuh COOP ini
app.use(cors({ origin: (o, cb) => cb(null, !o || origins.includes(o)), allowedHeaders: ['Content-Type', 'Authorization'] }));
app.use(express.json({ limit: '1mb' }));
app.use((_q, res, next) => { res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=(), usb=()'); next(); });
app.use('/v1', limit(300)); // batas global API per IP; rute sensitif punya batas lebih ketat sendiri

// Sesi = JWT HS256 berumur 1 jam di header Authorization (tanpa cookie, jadi tidak butuh CSRF).
const auth = (req, res, next) => {
  try {
    const t = (req.headers.authorization || '').replace(/^Bearer /, '');
    req.uid = jwt.verify(t, JWT_SECRET, { algorithms: ['HS256'], issuer: 'nama-apk' }).sub;
    next();
  } catch { res.status(401).json({ error: 'unauthorized' }); }
};

app.get('/health', (_q, r) => r.json({ status: 'ok', version: '22.0', storage: s3on, googleClientId: GOOGLE_CLIENT_ID, time: new Date().toISOString() }));

app.post('/v1/auth/google', limit(10), wrap(async (req, res) => {
  // verifyIdToken memeriksa tanda tangan, issuer, audience, dan masa berlaku.
  const ticket = await google.verifyIdToken({ idToken: String(req.body.credential || ''), audience: GOOGLE_CLIENT_ID }).catch(() => null);
  const p = ticket?.getPayload();
  if (!p || !p.email_verified) return res.status(401).json({ error: 'invalid_token' });
  const email = p.email.toLowerCase();
  if (allowedEmails.length && !allowedEmails.includes(email)) return res.status(403).json({ error: 'not_allowed' });
  const { rows: [u] } = await pool.query(
    `INSERT INTO users(google_sub,email,display_name) VALUES($1,$2,$3)
     ON CONFLICT(google_sub) DO UPDATE SET email=EXCLUDED.email, display_name=EXCLUDED.display_name
     RETURNING id,email,display_name,role`, [p.sub, email, p.name || email]);
  const token = jwt.sign({}, JWT_SECRET, { algorithm: 'HS256', subject: u.id, issuer: 'nama-apk', expiresIn: '1h' });
  await audit(u.id, 'login', 'user', u.id, req);
  res.json({ token, expiresIn: 3600, user: u });
}));

app.get('/v1/me', auth, wrap(async (req, res) => {
  const { rows: [u] } = await pool.query('SELECT id,email,display_name,role FROM users WHERE id=$1', [req.uid]);
  u ? res.json(u) : res.status(401).json({ error: 'unauthorized' });
}));

const COLS = `id, type, description AS "desc", category AS cat, amount::float8 AS amount,
              to_char(transaction_date,'YYYY-MM-DD') AS date, note`;
const listTx = (db, uid) => db.query(
  `SELECT ${COLS} FROM transactions WHERE owner_user_id=$1 AND deleted_at IS NULL ORDER BY transaction_date DESC, created_at DESC`, [uid]);
const validTx = t => t && UUID.test(t.id) && ['income', 'expense'].includes(t.type) && /^\d{4}-\d{2}-\d{2}$/.test(t.date)
  && Number.isFinite(+t.amount) && +t.amount >= 0 && +t.amount < 1e13 && String(t.desc ?? '').length <= 200
  && String(t.cat ?? '').length <= 100 && String(t.note ?? '').length <= 1000;

app.get('/v1/transactions', auth, wrap(async (req, res) => res.json({ items: (await listTx(pool, req.uid)).rows })));

// Push perubahan + hapus (soft delete), lalu kembalikan daftar otoritatif milik user ini.
app.post('/v1/sync', auth, limit(30), wrap(async (req, res) => {
  const { changed = [], deleted = [] } = req.body || {};
  if (!Array.isArray(changed) || !Array.isArray(deleted) || changed.length > 2000 || deleted.length > 2000
    || !changed.every(validTx) || !deleted.every(id => UUID.test(id))) return res.status(400).json({ error: 'invalid_payload' });
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    for (const t of changed) {
      // WHERE pada DO UPDATE = pemeriksaan pemilik: baris milik user lain tidak pernah tertimpa.
      await c.query(
        `INSERT INTO transactions(id,owner_user_id,type,description,category,amount,transaction_date,note)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8)
         ON CONFLICT(id) DO UPDATE SET type=EXCLUDED.type, description=EXCLUDED.description, category=EXCLUDED.category,
           amount=EXCLUDED.amount, transaction_date=EXCLUDED.transaction_date, note=EXCLUDED.note, deleted_at=NULL, updated_at=now()
         WHERE transactions.owner_user_id=EXCLUDED.owner_user_id`,
        [t.id, req.uid, t.type, t.desc ?? '', t.cat ?? '', t.amount, t.date, t.note ?? '']);
    }
    if (deleted.length) await c.query(
      'UPDATE transactions SET deleted_at=now(), updated_at=now() WHERE owner_user_id=$1 AND id=ANY($2::uuid[])', [req.uid, deleted]);
    const items = (await listTx(c, req.uid)).rows;
    await c.query('COMMIT');
    await audit(req.uid, 'sync', 'transactions', `${changed.length}+/${deleted.length}-`, req);
    res.json({ items });
  } catch (e) { await c.query('ROLLBACK').catch(() => {}); throw e; } finally { c.release(); }
}));

// Tautan hanya-baca: token acak 256-bit, hanya hash-nya disimpan, wajib kedaluwarsa, bisa dicabut.
app.post('/v1/shares', auth, limit(10), wrap(async (req, res) => {
  const month = String(req.body?.month || '');
  const days = Math.min(Math.max(parseInt(req.body?.days, 10) || 7, 1), 30);
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) return res.status(400).json({ error: 'invalid_month' });
  const token = crypto.randomBytes(32).toString('base64url');
  const { rows: [s] } = await pool.query(
    `INSERT INTO shares(owner_user_id,scope_month,token_hash,expires_at) VALUES($1,$2,$3,now()+make_interval(days=>$4))
     RETURNING id,expires_at`, [req.uid, month, sha(token), days]);
  await audit(req.uid, 'share_create', 'share', s.id, req);
  res.status(201).json({ id: s.id, url: `${PUBLIC_BASE_URL}/s/${token}`, expiresAt: s.expires_at });
}));

app.delete('/v1/shares/:id', auth, wrap(async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ error: 'invalid_id' });
  const r = await pool.query('UPDATE shares SET revoked_at=now() WHERE id=$1 AND owner_user_id=$2 AND revoked_at IS NULL', [req.params.id, req.uid]);
  if (!r.rowCount) return res.status(404).json({ error: 'not_found' });
  await audit(req.uid, 'share_revoke', 'share', req.params.id, req);
  res.status(204).end();
}));

// Halaman publik: render HTML statis dari server, tanpa JavaScript, tanpa endpoint tulis.
app.get('/s/:token', limit(30), wrap(async (req, res) => {
  res.set({ 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer', 'X-Robots-Tag': 'noindex, nofollow',
    'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'" });
  const { rows: [s] } = await pool.query(
    'SELECT id,owner_user_id,scope_month FROM shares WHERE token_hash=$1 AND revoked_at IS NULL AND expires_at>now()', [sha(req.params.token)]);
  if (!s) return res.status(404).type('html').send('<meta charset="utf-8"><h1>Tautan tidak valid atau sudah kedaluwarsa</h1>');
  const { rows } = await pool.query(
    `SELECT ${COLS} FROM transactions WHERE owner_user_id=$1 AND deleted_at IS NULL
       AND transaction_date >= ($2||'-01')::date AND transaction_date < (($2||'-01')::date + interval '1 month')
     ORDER BY transaction_date`, [s.owner_user_id, s.scope_month]);
  let inc = 0, exp = 0; rows.forEach(r => r.type === 'income' ? inc += r.amount : exp += r.amount);
  await audit(null, 'share_view', 'share', s.id, req);
  res.type('html').send(`<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex"><title>Laporan ${esc(s.scope_month)} · AuraLedger</title><style>
body{font:15px system-ui,sans-serif;background:#2b1f17;color:#f4ebe1;margin:0;padding:20px}main{max-width:760px;margin:auto}h1{font-size:20px;margin:0 0 4px}
.k{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}.k div{flex:1;min-width:150px;background:#3a2b21;border-radius:12px;padding:12px}
table{width:100%;border-collapse:collapse;margin-top:16px}td,th{padding:8px;border-bottom:1px solid #5a4636;text-align:left}td:last-child,th:last-child{text-align:right}
.i{color:#9fd8a8}.e{color:#f0a79a}small{color:#c9b8a6}</style></head><body><main>
<h1>Laporan Keuangan ${esc(s.scope_month)}</h1><small>Tampilan hanya-baca · AuraLedger</small>
<div class="k"><div><small>Pemasukan</small><br><b class="i">${rp(inc)}</b></div><div><small>Pengeluaran</small><br><b class="e">${rp(exp)}</b></div><div><small>Saldo</small><br><b>${rp(inc - exp)}</b></div></div>
<table><thead><tr><th>Tanggal</th><th>Keterangan</th><th>Jumlah</th></tr></thead><tbody>${rows.map(r =>
  `<tr><td>${esc(r.date)}</td><td>${esc(r.desc)}<br><small>${esc(r.cat)}</small></td><td class="${r.type === 'income' ? 'i' : 'e'}">${r.type === 'income' ? '+' : '−'}${rp(r.amount)}</td></tr>`).join('')}</tbody></table>
</main></body></html>`);
}));

// ----- V9 dokumen -----
// 1) minta URL unggah (validasi tipe/ukuran/kuota)  2) klien PUT langsung ke bucket  3) /complete memverifikasi ukuran objek.
app.post('/v1/documents/upload-url', auth, needS3, limit(20), wrap(async (req, res) => {
  const { filename, mime, size, folder = '' } = req.body || {};
  const name = String(filename || '').replace(/[\x00-\x1f\\/]/g, '_').slice(0, 200);
  if (!name || !MIMES.has(mime) || !Number.isInteger(size) || size < 1 || size > maxFile || String(folder).length > 100)
    return res.status(400).json({ error: 'invalid_file' });
  const { rows: [u] } = await pool.query(
    `SELECT COALESCE(SUM(size_bytes),0)::float8 AS used FROM documents
     WHERE owner_user_id=$1 AND deleted_at IS NULL AND (status='ready' OR created_at > now() - interval '1 hour')`, [req.uid]);
  if (u.used + size > quota) return res.status(413).json({ error: 'quota_exceeded' });
  const id = crypto.randomUUID(), key = `u/${req.uid}/${id}`; // nama file asli tidak pernah masuk object key
  await pool.query('INSERT INTO documents(id,owner_user_id,folder,object_key,filename,mime_type,size_bytes) VALUES($1,$2,$3,$4,$5,$6,$7)',
    [id, req.uid, String(folder), key, name, mime, size]);
  const uploadUrl = await getSignedUrl(s3, new PutObjectCommand({ Bucket: S3_BUCKET, Key: key, ContentType: mime, ContentLength: size }),
    { expiresIn: 300, signableHeaders: new Set(['content-type', 'content-length']) });
  res.status(201).json({ id, uploadUrl });
}));

app.post('/v1/documents/:id/complete', auth, needS3, wrap(async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ error: 'invalid_id' });
  const { rows: [d] } = await pool.query(
    `SELECT object_key, size_bytes::float8 AS size FROM documents WHERE id=$1 AND owner_user_id=$2 AND status='pending' AND deleted_at IS NULL`,
    [req.params.id, req.uid]);
  if (!d) return res.status(404).json({ error: 'not_found' });
  const head = await s3.send(new HeadObjectCommand({ Bucket: S3_BUCKET, Key: d.object_key })).catch(() => null);
  if (!head || head.ContentLength !== d.size) { // objek tidak ada / ukuran tidak cocok: buang
    await s3.send(new DeleteObjectCommand({ Bucket: S3_BUCKET, Key: d.object_key })).catch(() => {});
    await pool.query('DELETE FROM documents WHERE id=$1', [req.params.id]);
    return res.status(422).json({ error: 'upload_mismatch' });
  }
  const { rows: [doc] } = await pool.query(`UPDATE documents SET status='ready' WHERE id=$1 RETURNING ${DOC_COLS}`, [req.params.id]);
  await audit(req.uid, 'doc_upload', 'document', req.params.id, req);
  res.json(doc);
}));

app.get('/v1/documents', auth, needS3, wrap(async (req, res) => res.json({ items: (await pool.query(
  `SELECT ${DOC_COLS} FROM documents WHERE owner_user_id=$1 AND status='ready' AND deleted_at IS NULL ORDER BY created_at DESC`, [req.uid])).rows })));

app.get('/v1/documents/:id/download-url', auth, needS3, limit(60), wrap(async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ error: 'invalid_id' });
  const { rows: [d] } = await pool.query(
    `SELECT object_key, filename FROM documents WHERE id=$1 AND owner_user_id=$2 AND status='ready' AND deleted_at IS NULL`, [req.params.id, req.uid]);
  if (!d) return res.status(404).json({ error: 'not_found' });
  const url = await getSignedUrl(s3, new GetObjectCommand({ Bucket: S3_BUCKET, Key: d.object_key,
    ResponseContentType: 'application/octet-stream', // paksa unduh, jangan dirender di browser
    ResponseContentDisposition: `attachment; filename*=UTF-8''${encodeURIComponent(d.filename)}` }), { expiresIn: 120 });
  await audit(req.uid, 'doc_download', 'document', req.params.id, req);
  res.json({ url });
}));

app.delete('/v1/documents/:id', auth, needS3, wrap(async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ error: 'invalid_id' });
  const { rows: [d] } = await pool.query(
    'UPDATE documents SET deleted_at=now() WHERE id=$1 AND owner_user_id=$2 AND deleted_at IS NULL RETURNING object_key', [req.params.id, req.uid]);
  if (!d) return res.status(404).json({ error: 'not_found' });
  await audit(req.uid, 'doc_delete', 'document', req.params.id, req);
  res.status(204).end();
}));

// ----- V12: Riwayat Terhapus. Hapus = soft delete (pulih dalam TRASH_DAYS hari); objek bucket baru dihapus saat purge. -----
app.get('/v1/trash', auth, wrap(async (req, res) => {
  const transactions = (await pool.query(
    `SELECT ${COLS}, deleted_at FROM transactions WHERE owner_user_id=$1 AND deleted_at IS NOT NULL AND deleted_at > now() - make_interval(days=>$2)
     ORDER BY deleted_at DESC LIMIT 500`, [req.uid, TRASH_DAYS])).rows;
  const documents = s3on ? (await pool.query(
    `SELECT ${DOC_COLS}, deleted_at FROM documents WHERE owner_user_id=$1 AND status='ready' AND deleted_at IS NOT NULL AND deleted_at > now() - make_interval(days=>$2)
     ORDER BY deleted_at DESC LIMIT 500`, [req.uid, TRASH_DAYS])).rows : [];
  const books = (await pool.query(
    `SELECT b.id, b.kind, b.name, b.deleted_at,
            (SELECT count(*)::int FROM ledger_entries e WHERE e.book_id=b.id AND e.deleted_at=b.deleted_at) AS entries
       FROM ledger_books b WHERE b.owner_user_id=$1 AND b.deleted_at IS NOT NULL AND b.deleted_at > now() - make_interval(days=>$2)
       ORDER BY b.deleted_at DESC LIMIT 200`, [req.uid, TRASH_DAYS])).rows;
  res.json({ transactions, documents, books });
}));

app.delete('/v1/trash/transactions/:id', auth, wrap(async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ error: 'invalid_id' });
  const r = await pool.query('DELETE FROM transactions WHERE id=$1 AND owner_user_id=$2 AND deleted_at IS NOT NULL', [req.params.id, req.uid]);
  if (!r.rowCount) return res.status(404).json({ error: 'not_found' });
  await audit(req.uid, 'tx_purge', 'transaction', req.params.id, req);
  res.status(204).end();
}));

app.post('/v1/documents/:id/restore', auth, needS3, wrap(async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ error: 'invalid_id' });
  const { rows: [d] } = await pool.query(
    `SELECT size_bytes::float8 AS size FROM documents WHERE id=$1 AND owner_user_id=$2 AND status='ready' AND deleted_at IS NOT NULL
       AND deleted_at > now() - make_interval(days=>$3)`, [req.params.id, req.uid, TRASH_DAYS]);
  if (!d) return res.status(404).json({ error: 'not_found' });
  const { rows: [u] } = await pool.query(
    `SELECT COALESCE(SUM(size_bytes),0)::float8 AS used FROM documents WHERE owner_user_id=$1 AND deleted_at IS NULL AND (status='ready' OR created_at > now() - interval '1 hour')`, [req.uid]);
  if (u.used + d.size > quota) return res.status(413).json({ error: 'quota_exceeded' });
  const { rows: [doc] } = await pool.query(`UPDATE documents SET deleted_at=NULL WHERE id=$1 RETURNING ${DOC_COLS}`, [req.params.id]);
  await audit(req.uid, 'doc_restore', 'document', req.params.id, req);
  res.json(doc);
}));

app.delete('/v1/documents/:id/purge', auth, needS3, wrap(async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ error: 'invalid_id' });
  const { rows: [d] } = await pool.query('DELETE FROM documents WHERE id=$1 AND owner_user_id=$2 AND deleted_at IS NOT NULL RETURNING object_key', [req.params.id, req.uid]);
  if (!d) return res.status(404).json({ error: 'not_found' });
  await s3.send(new DeleteObjectCommand({ Bucket: S3_BUCKET, Key: d.object_key })).catch(console.error);
  await audit(req.uid, 'doc_purge', 'document', req.params.id, req);
  res.status(204).end();
}));

// ----- V18: Multi-Buku. Validasi ketat di server (lib/ledger.mjs) + CHECK/UNIQUE di basis data; semua perubahan dalam satu transaksi. -----
async function bookState(db, uid) {
  const books = (await db.query(
    `SELECT id, kind, name, fee_cents::float8 AS fee, members FROM ledger_books WHERE owner_user_id=$1 AND deleted_at IS NULL ORDER BY created_at, id`, [uid])).rows;
  const ents = (await db.query(
    `SELECT id, book_id, to_char(entry_date,'YYYY-MM-DD') AS date, member, detail, month, dir,
            weight_ckg::float8 AS weight_ckg, price_cents::float8 AS price_cents, cents::float8 AS cents
       FROM ledger_entries WHERE owner_user_id=$1 AND deleted_at IS NULL ORDER BY entry_date, created_at, id`, [uid])).rows;
  const by = new Map(books.map(b => [b.id, []]));
  for (const r of ents) by.get(r.book_id)?.push(r);
  return books.map(b => ({ id: b.id, kind: b.kind, name: b.name, fee: b.fee, members: b.members, entries: by.get(b.id).map(r => fromRow(b.kind, r)) }));
}

app.get('/v1/books', auth, wrap(async (req, res) => res.json({ books: await bookState(pool, req.uid) })));

app.post('/v1/books/sync', auth, limit(30), wrap(async (req, res) => {
  const p = validateSync(req.body);
  if (p.error) return res.status(400).json({ error: 'invalid_payload', detail: p.error });
  const bad = (detail, code = 400, error = 'invalid_payload') => res.status(code).json({ error, detail });
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    for (const b of p.books) {
      await c.query(
        `INSERT INTO ledger_books(id,owner_user_id,kind,name,fee_cents,members) VALUES($1,$2,$3,$4,$5,$6)
         ON CONFLICT(id) DO UPDATE SET name=EXCLUDED.name, fee_cents=EXCLUDED.fee_cents, members=EXCLUDED.members, deleted_at=NULL, updated_at=now()
         WHERE ledger_books.owner_user_id=EXCLUDED.owner_user_id AND ledger_books.kind=EXCLUDED.kind`,
        [b.id, req.uid, b.kind, b.name.trim(), b.fee, JSON.stringify(b.members)]);
    }
    const ids = [...new Set(p.entries.map(e => e.bookId))];
    const kinds = new Map((await c.query('SELECT id, kind FROM ledger_books WHERE owner_user_id=$1 AND deleted_at IS NULL AND id=ANY($2::uuid[])', [req.uid, ids])).rows.map(r => [r.id, r.kind]));
    for (const e of p.entries) {
      const kind = kinds.get(e.bookId);
      const err = kind ? validateEntry(kind, e) : 'Buku untuk entri ' + e.id + ' tidak ditemukan.';
      if (err) { await c.query('ROLLBACK'); return bad(err); }
      const r = toRow(kind, e);
      // WHERE pada DO UPDATE = pemeriksaan pemilik & buku: entri milik user/buku lain tidak pernah tertimpa.
      await c.query(
        `INSERT INTO ledger_entries(id,book_id,owner_user_id,entry_date,member,detail,month,dir,weight_ckg,price_cents,cents)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
         ON CONFLICT(id) DO UPDATE SET entry_date=EXCLUDED.entry_date, member=EXCLUDED.member, detail=EXCLUDED.detail, month=EXCLUDED.month, dir=EXCLUDED.dir,
           weight_ckg=EXCLUDED.weight_ckg, price_cents=EXCLUDED.price_cents, cents=EXCLUDED.cents, deleted_at=NULL, updated_at=now()
         WHERE ledger_entries.owner_user_id=EXCLUDED.owner_user_id AND ledger_entries.book_id=EXCLUDED.book_id`,
        [e.id, e.bookId, req.uid, r.entry_date, r.member, r.detail, r.month, r.dir, r.weight_ckg, r.price_cents, r.cents]);
    }
    if (p.deletedEntries.length) await c.query('UPDATE ledger_entries SET deleted_at=now(), updated_at=now() WHERE owner_user_id=$1 AND id=ANY($2::uuid[]) AND deleted_at IS NULL', [req.uid, p.deletedEntries]);
    if (p.deletedBooks.length) {
      await c.query('UPDATE ledger_entries SET deleted_at=now(), updated_at=now() WHERE owner_user_id=$1 AND book_id=ANY($2::uuid[]) AND deleted_at IS NULL', [req.uid, p.deletedBooks]);
      await c.query('UPDATE ledger_books SET deleted_at=now(), updated_at=now() WHERE owner_user_id=$1 AND id=ANY($2::uuid[]) AND deleted_at IS NULL', [req.uid, p.deletedBooks]);
    }
    const n = (await c.query('SELECT count(*)::int AS n FROM ledger_entries WHERE owner_user_id=$1 AND deleted_at IS NULL', [req.uid])).rows[0].n;
    if (n > 100000) { await c.query('ROLLBACK'); return bad('Batas 100.000 entri per akun tercapai.', 413, 'quota_exceeded'); }
    const books = await bookState(c, req.uid);
    await c.query('COMMIT');
    await audit(req.uid, 'books_sync', 'books', `${p.books.length}b/${p.entries.length}e/-${p.deletedBooks.length + p.deletedEntries.length}`, req);
    res.json({ books });
  } catch (e) {
    await c.query('ROLLBACK').catch(() => {});
    if (e.code === '23505') return bad('Iuran ganda untuk warga dan bulan yang sama.', 409, 'duplicate_iuran');
    if (['23514', '22P02', '22007', '22008', '22003'].includes(e.code)) return bad('Data ditolak oleh aturan basis data.');
    throw e;
  } finally { c.release(); }
}));

// ----- V19: pulihkan buku terhapus. Penghapusan buku memberi entri-entrinya cap waktu yang sama (satu transaksi), sehingga hanya
// entri yang ikut terhapus bersama bukunya yang dipulihkan; entri yang dihapus lebih dulu tetap di sampah. Perbandingan waktu dilakukan di SQL (presisi mikrodetik). -----
app.post('/v1/books/:id/restore', auth, limit(20), wrap(async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ error: 'invalid_id' });
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const f = await c.query(
      `SELECT 1 FROM ledger_books WHERE id=$1 AND owner_user_id=$2 AND deleted_at IS NOT NULL AND deleted_at > now() - make_interval(days=>$3) FOR UPDATE`,
      [req.params.id, req.uid, TRASH_DAYS]);
    if (!f.rowCount) { await c.query('ROLLBACK'); return res.status(404).json({ error: 'not_found' }); }
    await c.query(
      `UPDATE ledger_entries e SET deleted_at=NULL, updated_at=now() FROM ledger_books b
        WHERE e.book_id=b.id AND b.id=$1 AND b.owner_user_id=$2 AND e.owner_user_id=$2 AND e.deleted_at = b.deleted_at`, [req.params.id, req.uid]);
    await c.query('UPDATE ledger_books SET deleted_at=NULL, updated_at=now() WHERE id=$1 AND owner_user_id=$2', [req.params.id, req.uid]);
    await c.query('COMMIT');
    await audit(req.uid, 'book_restore', 'book', req.params.id, req);
    res.json({ ok: true });
  } catch (e) {
    await c.query('ROLLBACK').catch(() => {});
    if (e.code === '23505') return res.status(409).json({ error: 'duplicate_iuran', detail: 'Pemulihan menimbulkan iuran ganda.' });
    throw e;
  } finally { c.release(); }
}));

app.delete('/v1/trash/books/:id', auth, wrap(async (req, res) => {
  if (!UUID.test(req.params.id)) return res.status(400).json({ error: 'invalid_id' });
  const r = await pool.query('DELETE FROM ledger_books WHERE id=$1 AND owner_user_id=$2 AND deleted_at IS NOT NULL', [req.params.id, req.uid]);
  if (!r.rowCount) return res.status(404).json({ error: 'not_found' });
  await audit(req.uid, 'book_purge', 'book', req.params.id, req);
  res.status(204).end();
}));

// Pembersihan berkala: sampah kedaluwarsa + unggahan yatim (pending > 1 hari).
async function purgeExpired() {
  try {
    const { rows } = await pool.query(
      `DELETE FROM documents WHERE deleted_at < now() - make_interval(days=>$1) OR (status='pending' AND created_at < now() - interval '1 day') RETURNING object_key`, [TRASH_DAYS]);
    if (s3on) for (const d of rows) await s3.send(new DeleteObjectCommand({ Bucket: S3_BUCKET, Key: d.object_key })).catch(console.error);
    await pool.query('DELETE FROM transactions WHERE deleted_at < now() - make_interval(days=>$1)', [TRASH_DAYS]);
    await pool.query('DELETE FROM ledger_entries WHERE deleted_at < now() - make_interval(days=>$1)', [TRASH_DAYS]);
    await pool.query('DELETE FROM ledger_books WHERE deleted_at < now() - make_interval(days=>$1)', [TRASH_DAYS]);
  } catch (e) { console.error('purge', e); }
}
purgeExpired(); setInterval(purgeExpired, 6 * 3600e3).unref();

// ----- V10: sajikan PWA dari origin yang sama (tanpa masalah CORS; satu domain untuk Google OAuth) -----
const PUBLIC_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'public');
// CSP berbasis hash: hanya skrip sisipan yang hash-nya cocok (dihitung dari public/index.html saat start) yang boleh jalan.
// Skrip hasil injeksi (XSS) dan atribut onerror/onclick otomatis diblokir peramban.
const INLINE_HASHES = [...fs.readFileSync(path.join(PUBLIC_DIR, 'index.html'), 'utf8').matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g)]
  .map(m => `'sha256-${crypto.createHash('sha256').update(m[1]).digest('base64')}'`).join(' ');
const CSP = ["default-src 'self'", `script-src 'self' ${INLINE_HASHES} https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js https://accounts.google.com/gsi/client`,
  "script-src-attr 'none'", "form-action 'self'",
  "style-src 'self' 'unsafe-inline' https://accounts.google.com/gsi/style", "img-src 'self' data: blob: https://*.googleusercontent.com",
  `connect-src 'self' https://accounts.google.com/gsi/ https://www.googleapis.com ${S3_ENDPOINT ? new URL(S3_ENDPOINT).origin : ''} https://*.amazonaws.com https://*.r2.cloudflarestorage.com`,
  "frame-src https://accounts.google.com/gsi/", "worker-src 'self'", "manifest-src 'self'", "object-src 'none'", "base-uri 'self'", "frame-ancestors 'none'"].join('; ');
app.use(express.static(PUBLIC_DIR, { setHeaders: (res, f) => {
  res.setHeader('Content-Security-Policy', CSP);
  if (/(sw\.js|index\.html)$/.test(f)) res.setHeader('Cache-Control', 'no-cache');
} }));

// Digital Asset Links untuk APK (TWA): membuat aplikasi Android tampil layar penuh tanpa bilah alamat.
app.use('/.well-known', express.static(path.join(PUBLIC_DIR, '.well-known'), { setHeaders: res => res.setHeader('Cache-Control', 'no-cache') }));

// Penangan galat terakhir: tidak pernah membocorkan stack trace; JSON rusak -> 400.
app.use((err, _req, res, _next) => {
  const status = err && err.status >= 400 && err.status < 500 ? err.status : 500;
  if (status === 500) console.error(err);
  res.status(status).json({ error: status === 500 ? 'server_error' : 'bad_request' });
});

app.listen(PORT, () => console.log(`AuraLedger backend V14 di :${PORT}`));
